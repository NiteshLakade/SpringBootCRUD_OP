package com.student.SpringBootCrud.repository;

import org.springframework.data.repository.CrudRepository;

import com.student.SpringBootCrud.bean.Student;

public interface StudentRepository extends CrudRepository<Student, String>  {
  
	
}
